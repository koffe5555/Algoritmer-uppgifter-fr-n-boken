﻿using System;

namespace Algoritmer
{
    class Program
    {
        static void Main(string[] args)
        {
            double[] unsortedArray = { 4, 2, 7, 8, 9, 10, 1, 3 };

            //InsertSort
            // Console.WriteLine("Insert Sort: ");
            // Console.WriteLine("Initial array: " );
            // PrintArray(unsortedArray);
            // Console.WriteLine("\nSorted array: ");
            // InsertionSort(unsortedArray);


            //SelectionSort
            // Console.WriteLine("\nSelection Sort: ");
            // Console.WriteLine("Initial array: " );
            // PrintArray(unsortedArray);
            // Console.WriteLine("\nSorted array: " );
            // SelectionSort(unsortedArray);


            //BubbleSort
            // Console.WriteLine("Bubble Sort: ");
            // Console.WriteLine("Initial Array: ");
            // PrintArray(unsortedArray); 
            // Console.WriteLine("\nSorted: ");
            // BubbleSort(unsortedArray);

            //Heap

            // int[] arr = { 12, 11, 13, 5, 6, 7 };
            // int n = unsortedArray.Length;
            // HeapSort obj = new HeapSort();
            // obj.sort(arr);

            //CountingSort
            int[] arr = {0, 2, 3, 4, 7, 2, 3, 8, 4, 8, 2, 3, 4, 0, 0, 5, 2, 1, 8, 2, 1, 9, 3, 3, 3, 3,};
            int range = 10;
            int[] resultArray = CountingSort(arr, range);
            Console.WriteLine("Sorted array: \n");
            PrintIntArray(resultArray);
        }

        private static void PrintIntArray(int[] arr)
        {
            for(int i = 0; i < arr.Length; i++)
            {
                Console.Write(arr[i] + " ");
            }
        }

        private static int[] CountingSort(int[] arr, int range)
        {
            int[] CountArray = new int[range];

            for(int i = 0; i < arr.Length; i++)
            {
                CountArray[arr[i]]++;
            }

            for(int i = 1; i < range; i++)
            {
                CountArray[i] = CountArray[i] + CountArray[i - 1];
            }

            int[] resultArray = new int[arr.Length];

            for(int i = arr.Length - 1; i >= 0; i--)
            {
                resultArray[CountArray[arr[i]] - 1] = arr[i];

                CountArray[arr[i]] = CountArray[arr[i]] - 1;
            }
            return resultArray;
        }

        private static void BubbleSort(double[] unsortedArray)
        {
            double temp;

            for (int i = 0; i < unsortedArray.Length - 1; i++)
            {
                for (int j = 0; j < unsortedArray.Length - (1 + i); j++)
                {
                    if (unsortedArray[j] > unsortedArray[j + 1])
                    {
                        temp = unsortedArray[j + 1];
                        unsortedArray[j + 1] = unsortedArray[j];
                        unsortedArray[j] = temp;
                    }
                }
            }
            PrintArray(unsortedArray);
        }

        private static void SelectionSort(double[] unsortedArray)
        {
            int MinIndex = 0; // Current index of the current minimum we are looking for
            double MinValueFound = 0; // temp variable for swaping the value of MinIndex

            //Börja loopa från början till slutet av arrayen
            for (int index = 0; index < unsortedArray.Length; index++)
            {
                MinIndex = index;

                //Loopar igenom och kollar om värdet vi står på är mindre än Minindex och om det är det byter vi värdena med varandra och fortsätter loopa.
                for (int RemainingIndex = MinIndex + 1; RemainingIndex < unsortedArray.Length; RemainingIndex++)
                {
                    if (unsortedArray[RemainingIndex] < unsortedArray[MinIndex])
                    {
                        MinIndex = RemainingIndex;
                    }
                }

                //Här sätter vi in vårat MinIndex som vi hittat så att om 10 ligger på plats 0 och 1 på plats 3 i arrayen kommer de bytas 
                //Vi fortsätter sedan loopa igenom arrayen från nästa värde så att vi stegrar uppåt (börja leta efter minsta och sedan näst minsta osv..)
                MinValueFound = unsortedArray[MinIndex];
                unsortedArray[MinIndex] = unsortedArray[index];
                unsortedArray[index] = MinValueFound;

            }
            PrintArray(unsortedArray);
        }

        private static void PrintArray(double[] unsortedArray)
        {
            for (int i = 0; i < unsortedArray.Length; i++)
            {
                Console.Write(unsortedArray[i] + " ");
            }
        }


        private static void InsertionSort(double[] unsortedArray)
        {
            int i = 1;
            int j = i;
            double temp = 0;
            while (i < unsortedArray.Length)
            {
                j = i;

                while (j > 0 && unsortedArray[j - 1] > unsortedArray[j])
                {
                    temp = unsortedArray[j];
                    unsortedArray[j] = unsortedArray[j - 1];
                    unsortedArray[j - 1] = temp;
                    j--;
                }
                i++;
            }
            PrintArray(unsortedArray);
        }
    }
}

        public class HeapSort
        {
            public void sort(int[] arr)
            {
                int n = arr.Length;

                // Build heap (rearrange array)
                for (int i = n / 2 - 1; i >= 0; i--)
                    heapify(arr, n, i);

                // One by one extract an element from heap
                for (int i = n - 1; i > 0; i--)
                {
                    // Move current root to end
                    int temp = arr[0];
                    arr[0] = arr[i];
                    arr[i] = temp;

                    // call max heapify on the reduced heap
                    heapify(arr, i, 0);
                    printArray(arr);
                }
            }

            // To heapify a subtree rooted with node i which is
            // an index in arr[]. n is size of heap
            void heapify(int[] arr, int n, int i)
            {
                int largest = i; // Initialize largest as root
                int l = 2 * i + 1; // left = 2*i + 1
                int r = 2 * i + 2; // right = 2*i + 2

                // If left child is larger than root
                if (l < n && arr[l] > arr[largest])
                    largest = l;

                // If right child is larger than largest so far
                if (r < n && arr[r] > arr[largest])
                    largest = r;

                // If largest is not root
                if (largest != i)
                {
                    int swap = arr[i];
                    arr[i] = arr[largest];
                    arr[largest] = swap;

                    // Recursively heapify the affected sub-tree
                    heapify(arr, n, largest);
                }
            }

            /* A utility function to print array of size n */
            static void printArray(int[] arr)
            {
                int n = arr.Length;
                for (int i = 0; i < n; ++i)
                    Console.Write(arr[i] + " ");
                Console.Read();
            }

        }